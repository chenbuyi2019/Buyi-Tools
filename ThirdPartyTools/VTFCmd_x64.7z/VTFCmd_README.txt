https://developer.valvesoftware.com/wiki/VTFCmd

https://web.archive.org/web/20190508141002/http://nemesis.thewavelength.net/index.php?c=177
